﻿namespace PBL3
{
    partial class FormDangKy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDangKy));
            this.panelBody = new System.Windows.Forms.Panel();
            this.butXnMa = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.txtcode = new Guna.UI2.WinForms.Guna2TextBox();
            this.gunaback = new Guna.UI2.WinForms.Guna2Button();
            this.txtemail = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtHoTen = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSDT = new Guna.UI2.WinForms.Guna2TextBox();
            this.butDangKy = new Guna.UI2.WinForms.Guna2Button();
            this.butViewMK = new Guna.UI2.WinForms.Guna2Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTenDangNhap = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMatKhau = new Guna.UI2.WinForms.Guna2TextBox();
            this.butHideMK = new Guna.UI2.WinForms.Guna2Button();
            this.txtNhapLaiMatKhau = new Guna.UI2.WinForms.Guna2TextBox();
            this.butHideNLMK = new Guna.UI2.WinForms.Guna2Button();
            this.butViewNLMK = new Guna.UI2.WinForms.Guna2Button();
            this.txtCMND = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDiaChi = new Guna.UI2.WinForms.Guna2TextBox();
            this.DatetimeNgaySinh = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.CheckboxNam = new Guna.UI2.WinForms.Guna2CheckBox();
            this.CheckboxNu = new Guna.UI2.WinForms.Guna2CheckBox();
            this.panelBody.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBody
            // 
            this.panelBody.BackColor = System.Drawing.Color.SlateGray;
            this.panelBody.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelBody.BackgroundImage")));
            this.panelBody.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelBody.Controls.Add(this.CheckboxNu);
            this.panelBody.Controls.Add(this.CheckboxNam);
            this.panelBody.Controls.Add(this.guna2HtmlLabel2);
            this.panelBody.Controls.Add(this.DatetimeNgaySinh);
            this.panelBody.Controls.Add(this.txtDiaChi);
            this.panelBody.Controls.Add(this.txtCMND);
            this.panelBody.Controls.Add(this.butXnMa);
            this.panelBody.Controls.Add(this.guna2HtmlLabel1);
            this.panelBody.Controls.Add(this.guna2Button1);
            this.panelBody.Controls.Add(this.txtcode);
            this.panelBody.Controls.Add(this.gunaback);
            this.panelBody.Controls.Add(this.txtemail);
            this.panelBody.Controls.Add(this.butViewNLMK);
            this.panelBody.Controls.Add(this.label1);
            this.panelBody.Controls.Add(this.txtHoTen);
            this.panelBody.Controls.Add(this.txtSDT);
            this.panelBody.Controls.Add(this.butDangKy);
            this.panelBody.Controls.Add(this.butViewMK);
            this.panelBody.Controls.Add(this.label4);
            this.panelBody.Controls.Add(this.txtTenDangNhap);
            this.panelBody.Controls.Add(this.txtMatKhau);
            this.panelBody.Controls.Add(this.butHideMK);
            this.panelBody.Controls.Add(this.txtNhapLaiMatKhau);
            this.panelBody.Controls.Add(this.butHideNLMK);
            this.panelBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBody.Location = new System.Drawing.Point(0, 0);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(984, 511);
            this.panelBody.TabIndex = 9;
            // 
            // butXnMa
            // 
            this.butXnMa.BorderRadius = 20;
            this.butXnMa.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butXnMa.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butXnMa.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butXnMa.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butXnMa.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.butXnMa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butXnMa.ForeColor = System.Drawing.Color.White;
            this.butXnMa.Location = new System.Drawing.Point(829, 158);
            this.butXnMa.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.butXnMa.Name = "butXnMa";
            this.butXnMa.Size = new System.Drawing.Size(71, 32);
            this.butXnMa.TabIndex = 140;
            this.butXnMa.Text = "Xác nhận";
            this.butXnMa.Click += new System.EventHandler(this.butXnMa_Click);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(506, 205);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(3, 2);
            this.guna2HtmlLabel1.TabIndex = 139;
            this.guna2HtmlLabel1.Text = null;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 20;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.guna2Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(757, 159);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(68, 31);
            this.guna2Button1.TabIndex = 138;
            this.guna2Button1.Text = "Gửi mã";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // txtcode
            // 
            this.txtcode.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtcode.BorderRadius = 20;
            this.txtcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcode.DefaultText = "";
            this.txtcode.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtcode.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtcode.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcode.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtcode.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcode.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtcode.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtcode.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtcode.IconLeft")));
            this.txtcode.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtcode.IconLeftSize = new System.Drawing.Size(25, 25);
            this.txtcode.Location = new System.Drawing.Point(622, 160);
            this.txtcode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtcode.Name = "txtcode";
            this.txtcode.PasswordChar = '\0';
            this.txtcode.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtcode.PlaceholderText = "Mã bảo mật";
            this.txtcode.SelectedText = "";
            this.txtcode.Size = new System.Drawing.Size(130, 34);
            this.txtcode.TabIndex = 137;
            // 
            // gunaback
            // 
            this.gunaback.BackColor = System.Drawing.Color.SlateGray;
            this.gunaback.BorderRadius = 21;
            this.gunaback.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gunaback.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gunaback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gunaback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gunaback.FillColor = System.Drawing.Color.SlateGray;
            this.gunaback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.gunaback.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(45)))), ((int)(((byte)(29)))));
            this.gunaback.Image = ((System.Drawing.Image)(resources.GetObject("gunaback.Image")));
            this.gunaback.ImageSize = new System.Drawing.Size(40, 40);
            this.gunaback.Location = new System.Drawing.Point(672, 3);
            this.gunaback.Name = "gunaback";
            this.gunaback.Size = new System.Drawing.Size(44, 39);
            this.gunaback.TabIndex = 136;
            this.gunaback.Click += new System.EventHandler(this.gunaback_Click);
            // 
            // txtemail
            // 
            this.txtemail.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtemail.BorderRadius = 20;
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.DefaultText = "";
            this.txtemail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtemail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtemail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtemail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtemail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtemail.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtemail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtemail.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtemail.IconLeft")));
            this.txtemail.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtemail.Location = new System.Drawing.Point(622, 119);
            this.txtemail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtemail.Name = "txtemail";
            this.txtemail.PasswordChar = '\0';
            this.txtemail.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtemail.PlaceholderText = "Email";
            this.txtemail.SelectedText = "";
            this.txtemail.Size = new System.Drawing.Size(278, 37);
            this.txtemail.TabIndex = 135;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Constantia", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.label1.Location = new System.Drawing.Point(722, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 24);
            this.label1.TabIndex = 95;
            this.label1.Text = "Đăng ký";
            // 
            // txtHoTen
            // 
            this.txtHoTen.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtHoTen.BorderRadius = 20;
            this.txtHoTen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtHoTen.DefaultText = "";
            this.txtHoTen.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtHoTen.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtHoTen.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtHoTen.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtHoTen.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtHoTen.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtHoTen.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtHoTen.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtHoTen.IconLeft")));
            this.txtHoTen.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtHoTen.IconLeftSize = new System.Drawing.Size(22, 22);
            this.txtHoTen.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtHoTen.Location = new System.Drawing.Point(622, 47);
            this.txtHoTen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.PasswordChar = '\0';
            this.txtHoTen.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtHoTen.PlaceholderText = "Họ và tên";
            this.txtHoTen.SelectedText = "";
            this.txtHoTen.Size = new System.Drawing.Size(278, 34);
            this.txtHoTen.TabIndex = 131;
            // 
            // txtSDT
            // 
            this.txtSDT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtSDT.BorderRadius = 20;
            this.txtSDT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSDT.DefaultText = "";
            this.txtSDT.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSDT.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSDT.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSDT.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSDT.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSDT.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtSDT.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSDT.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtSDT.IconLeft")));
            this.txtSDT.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtSDT.IconLeftSize = new System.Drawing.Size(28, 28);
            this.txtSDT.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtSDT.Location = new System.Drawing.Point(622, 85);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.PasswordChar = '\0';
            this.txtSDT.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtSDT.PlaceholderText = "Số điện thoại ";
            this.txtSDT.SelectedText = "";
            this.txtSDT.Size = new System.Drawing.Size(278, 30);
            this.txtSDT.TabIndex = 130;
            // 
            // butDangKy
            // 
            this.butDangKy.BorderRadius = 20;
            this.butDangKy.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butDangKy.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butDangKy.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butDangKy.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butDangKy.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.butDangKy.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDangKy.ForeColor = System.Drawing.Color.White;
            this.butDangKy.Location = new System.Drawing.Point(622, 447);
            this.butDangKy.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.butDangKy.Name = "butDangKy";
            this.butDangKy.Size = new System.Drawing.Size(278, 42);
            this.butDangKy.TabIndex = 129;
            this.butDangKy.Text = "Đăng ký";
            this.butDangKy.Click += new System.EventHandler(this.butDangKy_Click);
            // 
            // butViewMK
            // 
            this.butViewMK.Animated = true;
            this.butViewMK.BackColor = System.Drawing.Color.Transparent;
            this.butViewMK.BorderRadius = 8;
            this.butViewMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butViewMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butViewMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butViewMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butViewMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butViewMK.FillColor = System.Drawing.Color.White;
            this.butViewMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butViewMK.ForeColor = System.Drawing.Color.White;
            this.butViewMK.Image = ((System.Drawing.Image)(resources.GetObject("butViewMK.Image")));
            this.butViewMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butViewMK.Location = new System.Drawing.Point(869, 376);
            this.butViewMK.Name = "butViewMK";
            this.butViewMK.Size = new System.Drawing.Size(31, 30);
            this.butViewMK.TabIndex = 127;
            this.butViewMK.Click += new System.EventHandler(this.butViewMK_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(641, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 21);
            this.label4.TabIndex = 96;
            this.label4.Text = "__________________________________";
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtTenDangNhap.BorderRadius = 20;
            this.txtTenDangNhap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenDangNhap.DefaultText = "";
            this.txtTenDangNhap.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTenDangNhap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTenDangNhap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenDangNhap.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenDangNhap.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenDangNhap.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtTenDangNhap.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenDangNhap.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtTenDangNhap.IconLeft")));
            this.txtTenDangNhap.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtTenDangNhap.IconLeftSize = new System.Drawing.Size(22, 22);
            this.txtTenDangNhap.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtTenDangNhap.Location = new System.Drawing.Point(622, 337);
            this.txtTenDangNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.PasswordChar = '\0';
            this.txtTenDangNhap.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtTenDangNhap.PlaceholderText = "Tên đăng nhập ";
            this.txtTenDangNhap.SelectedText = "";
            this.txtTenDangNhap.Size = new System.Drawing.Size(278, 34);
            this.txtTenDangNhap.TabIndex = 92;
            // 
            // txtMatKhau
            // 
            this.txtMatKhau.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtMatKhau.BorderRadius = 20;
            this.txtMatKhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMatKhau.DefaultText = "";
            this.txtMatKhau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMatKhau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMatKhau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhau.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtMatKhau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhau.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtMatKhau.IconLeft")));
            this.txtMatKhau.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtMatKhau.IconLeftSize = new System.Drawing.Size(25, 25);
            this.txtMatKhau.Location = new System.Drawing.Point(622, 377);
            this.txtMatKhau.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMatKhau.Name = "txtMatKhau";
            this.txtMatKhau.PasswordChar = '●';
            this.txtMatKhau.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtMatKhau.PlaceholderText = "Mật khẩu";
            this.txtMatKhau.SelectedText = "";
            this.txtMatKhau.Size = new System.Drawing.Size(278, 30);
            this.txtMatKhau.TabIndex = 94;
            this.txtMatKhau.UseSystemPasswordChar = true;
            // 
            // butHideMK
            // 
            this.butHideMK.Animated = true;
            this.butHideMK.BackColor = System.Drawing.Color.Transparent;
            this.butHideMK.BorderRadius = 8;
            this.butHideMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butHideMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHideMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHideMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHideMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHideMK.FillColor = System.Drawing.Color.White;
            this.butHideMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butHideMK.ForeColor = System.Drawing.Color.White;
            this.butHideMK.Image = ((System.Drawing.Image)(resources.GetObject("butHideMK.Image")));
            this.butHideMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butHideMK.Location = new System.Drawing.Point(869, 376);
            this.butHideMK.Name = "butHideMK";
            this.butHideMK.Size = new System.Drawing.Size(31, 30);
            this.butHideMK.TabIndex = 128;
            this.butHideMK.Click += new System.EventHandler(this.butHideMK_Click);
            // 
            // txtNhapLaiMatKhau
            // 
            this.txtNhapLaiMatKhau.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtNhapLaiMatKhau.BorderRadius = 20;
            this.txtNhapLaiMatKhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNhapLaiMatKhau.DefaultText = "";
            this.txtNhapLaiMatKhau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtNhapLaiMatKhau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtNhapLaiMatKhau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtNhapLaiMatKhau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtNhapLaiMatKhau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNhapLaiMatKhau.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtNhapLaiMatKhau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNhapLaiMatKhau.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtNhapLaiMatKhau.IconLeft")));
            this.txtNhapLaiMatKhau.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtNhapLaiMatKhau.IconLeftSize = new System.Drawing.Size(25, 25);
            this.txtNhapLaiMatKhau.Location = new System.Drawing.Point(622, 413);
            this.txtNhapLaiMatKhau.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapLaiMatKhau.Name = "txtNhapLaiMatKhau";
            this.txtNhapLaiMatKhau.PasswordChar = '●';
            this.txtNhapLaiMatKhau.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtNhapLaiMatKhau.PlaceholderText = "Nhập lại mật khẩu";
            this.txtNhapLaiMatKhau.SelectedText = "";
            this.txtNhapLaiMatKhau.Size = new System.Drawing.Size(278, 30);
            this.txtNhapLaiMatKhau.TabIndex = 132;
            this.txtNhapLaiMatKhau.UseSystemPasswordChar = true;
            // 
            // butHideNLMK
            // 
            this.butHideNLMK.Animated = true;
            this.butHideNLMK.BackColor = System.Drawing.Color.Transparent;
            this.butHideNLMK.BorderRadius = 8;
            this.butHideNLMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butHideNLMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHideNLMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHideNLMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHideNLMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHideNLMK.FillColor = System.Drawing.Color.White;
            this.butHideNLMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butHideNLMK.ForeColor = System.Drawing.Color.White;
            this.butHideNLMK.Image = ((System.Drawing.Image)(resources.GetObject("butHideNLMK.Image")));
            this.butHideNLMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butHideNLMK.Location = new System.Drawing.Point(869, 412);
            this.butHideNLMK.Name = "butHideNLMK";
            this.butHideNLMK.Size = new System.Drawing.Size(31, 30);
            this.butHideNLMK.TabIndex = 134;
            this.butHideNLMK.Click += new System.EventHandler(this.butHideNLMK_Click);
            // 
            // butViewNLMK
            // 
            this.butViewNLMK.Animated = true;
            this.butViewNLMK.BackColor = System.Drawing.Color.Transparent;
            this.butViewNLMK.BorderRadius = 8;
            this.butViewNLMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butViewNLMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butViewNLMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butViewNLMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butViewNLMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butViewNLMK.FillColor = System.Drawing.Color.White;
            this.butViewNLMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butViewNLMK.ForeColor = System.Drawing.Color.White;
            this.butViewNLMK.Image = ((System.Drawing.Image)(resources.GetObject("butViewNLMK.Image")));
            this.butViewNLMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butViewNLMK.Location = new System.Drawing.Point(869, 412);
            this.butViewNLMK.Name = "butViewNLMK";
            this.butViewNLMK.Size = new System.Drawing.Size(31, 30);
            this.butViewNLMK.TabIndex = 133;
            this.butViewNLMK.Click += new System.EventHandler(this.butViewNLMK_Click);
            // 
            // txtCMND
            // 
            this.txtCMND.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtCMND.BorderRadius = 20;
            this.txtCMND.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCMND.DefaultText = "";
            this.txtCMND.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtCMND.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtCMND.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCMND.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCMND.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCMND.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtCMND.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCMND.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtCMND.IconLeft")));
            this.txtCMND.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtCMND.IconLeftSize = new System.Drawing.Size(28, 28);
            this.txtCMND.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtCMND.Location = new System.Drawing.Point(622, 236);
            this.txtCMND.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.PasswordChar = '\0';
            this.txtCMND.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtCMND.PlaceholderText = "CMND";
            this.txtCMND.SelectedText = "";
            this.txtCMND.Size = new System.Drawing.Size(278, 30);
            this.txtCMND.TabIndex = 142;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtDiaChi.BorderRadius = 20;
            this.txtDiaChi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDiaChi.DefaultText = "";
            this.txtDiaChi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDiaChi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDiaChi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiaChi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiaChi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtDiaChi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiaChi.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtDiaChi.IconLeft")));
            this.txtDiaChi.IconLeftOffset = new System.Drawing.Point(4, 0);
            this.txtDiaChi.IconLeftSize = new System.Drawing.Size(28, 28);
            this.txtDiaChi.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txtDiaChi.Location = new System.Drawing.Point(622, 198);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.PasswordChar = '\0';
            this.txtDiaChi.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtDiaChi.PlaceholderText = "Địa chỉ ";
            this.txtDiaChi.SelectedText = "";
            this.txtDiaChi.Size = new System.Drawing.Size(278, 30);
            this.txtDiaChi.TabIndex = 143;
            // 
            // DatetimeNgaySinh
            // 
            this.DatetimeNgaySinh.AutoRoundedCorners = true;
            this.DatetimeNgaySinh.BorderRadius = 13;
            this.DatetimeNgaySinh.Checked = true;
            this.DatetimeNgaySinh.FillColor = System.Drawing.Color.White;
            this.DatetimeNgaySinh.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.DatetimeNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DatetimeNgaySinh.Location = new System.Drawing.Point(691, 271);
            this.DatetimeNgaySinh.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.DatetimeNgaySinh.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.DatetimeNgaySinh.Name = "DatetimeNgaySinh";
            this.DatetimeNgaySinh.Size = new System.Drawing.Size(209, 28);
            this.DatetimeNgaySinh.TabIndex = 145;
            this.DatetimeNgaySinh.Value = new System.DateTime(2022, 6, 13, 15, 10, 54, 897);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(622, 281);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(63, 18);
            this.guna2HtmlLabel2.TabIndex = 146;
            this.guna2HtmlLabel2.Text = "Ngày sinh";
            // 
            // CheckboxNam
            // 
            this.CheckboxNam.AutoSize = true;
            this.CheckboxNam.CheckedState.BorderColor = System.Drawing.Color.Navy;
            this.CheckboxNam.CheckedState.BorderRadius = 0;
            this.CheckboxNam.CheckedState.BorderThickness = 0;
            this.CheckboxNam.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CheckboxNam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.CheckboxNam.Location = new System.Drawing.Point(627, 312);
            this.CheckboxNam.Name = "CheckboxNam";
            this.CheckboxNam.Size = new System.Drawing.Size(58, 20);
            this.CheckboxNam.TabIndex = 147;
            this.CheckboxNam.Text = "Nam ";
            this.CheckboxNam.UncheckedState.BorderColor = System.Drawing.Color.Navy;
            this.CheckboxNam.UncheckedState.BorderRadius = 0;
            this.CheckboxNam.UncheckedState.BorderThickness = 0;
            this.CheckboxNam.UncheckedState.FillColor = System.Drawing.Color.LightSteelBlue;
            // 
            // CheckboxNu
            // 
            this.CheckboxNu.AutoSize = true;
            this.CheckboxNu.CheckedState.BorderColor = System.Drawing.Color.Navy;
            this.CheckboxNu.CheckedState.BorderRadius = 0;
            this.CheckboxNu.CheckedState.BorderThickness = 0;
            this.CheckboxNu.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CheckboxNu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.CheckboxNu.Location = new System.Drawing.Point(811, 312);
            this.CheckboxNu.Name = "CheckboxNu";
            this.CheckboxNu.Size = new System.Drawing.Size(43, 20);
            this.CheckboxNu.TabIndex = 148;
            this.CheckboxNu.Text = "Nữ";
            this.CheckboxNu.UncheckedState.BorderColor = System.Drawing.Color.Navy;
            this.CheckboxNu.UncheckedState.BorderRadius = 0;
            this.CheckboxNu.UncheckedState.BorderThickness = 0;
            this.CheckboxNu.UncheckedState.FillColor = System.Drawing.Color.LightSteelBlue;
            // 
            // FormDangKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 511);
            this.Controls.Add(this.panelBody);
            this.Name = "FormDangKy";
            this.Text = "FormDangKy";
            this.panelBody.ResumeLayout(false);
            this.panelBody.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBody;
        private Guna.UI2.WinForms.Guna2Button butDangKy;
        private Guna.UI2.WinForms.Guna2Button butViewMK;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtMatKhau;
        private Guna.UI2.WinForms.Guna2TextBox txtTenDangNhap;
        private Guna.UI2.WinForms.Guna2Button butHideMK;
        private Guna.UI2.WinForms.Guna2TextBox txtHoTen;
        private Guna.UI2.WinForms.Guna2TextBox txtSDT;
        private Guna.UI2.WinForms.Guna2TextBox txtNhapLaiMatKhau;
        private Guna.UI2.WinForms.Guna2Button butHideNLMK;
        private Guna.UI2.WinForms.Guna2TextBox txtemail;
        private Guna.UI2.WinForms.Guna2Button gunaback;
        private Guna.UI2.WinForms.Guna2TextBox txtcode;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button butXnMa;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button butViewNLMK;
        private Guna.UI2.WinForms.Guna2CheckBox CheckboxNu;
        private Guna.UI2.WinForms.Guna2CheckBox CheckboxNam;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2DateTimePicker DatetimeNgaySinh;
        private Guna.UI2.WinForms.Guna2TextBox txtDiaChi;
        private Guna.UI2.WinForms.Guna2TextBox txtCMND;
    }
}