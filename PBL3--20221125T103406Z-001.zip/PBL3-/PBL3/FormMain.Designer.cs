﻿namespace PBL3
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.butDoanhThu = new Guna.UI2.WinForms.Guna2GradientButton();
            this.butPhuKien = new Guna.UI2.WinForms.Guna2GradientButton();
            this.butNhacCu = new Guna.UI2.WinForms.Guna2GradientButton();
            this.butHoaDon = new Guna.UI2.WinForms.Guna2GradientButton();
            this.butKhachHang = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.butThongTin = new System.Windows.Forms.Button();
            this.butThoat = new System.Windows.Forms.Button();
            this.labelTenND = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.labelMaND = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelBody = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.guna2GradientButton6);
            this.panel1.Controls.Add(this.butDoanhThu);
            this.panel1.Controls.Add(this.butPhuKien);
            this.panel1.Controls.Add(this.butNhacCu);
            this.panel1.Controls.Add(this.butHoaDon);
            this.panel1.Controls.Add(this.butKhachHang);
            this.panel1.Controls.Add(this.guna2Panel1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 678);
            this.panel1.TabIndex = 0;
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton6.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientButton6.FillColor = System.Drawing.Color.Gray;
            this.guna2GradientButton6.FillColor2 = System.Drawing.Color.Silver;
            this.guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientButton6.Location = new System.Drawing.Point(0, 558);
            this.guna2GradientButton6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.Size = new System.Drawing.Size(197, 55);
            this.guna2GradientButton6.TabIndex = 1;
            this.guna2GradientButton6.Text = "Người dùng";
            // 
            // butDoanhThu
            // 
            this.butDoanhThu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butDoanhThu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butDoanhThu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butDoanhThu.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butDoanhThu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butDoanhThu.FillColor = System.Drawing.Color.DimGray;
            this.butDoanhThu.FillColor2 = System.Drawing.Color.Gainsboro;
            this.butDoanhThu.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.butDoanhThu.ForeColor = System.Drawing.Color.Black;
            this.butDoanhThu.Location = new System.Drawing.Point(0, 475);
            this.butDoanhThu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butDoanhThu.Name = "butDoanhThu";
            this.butDoanhThu.Size = new System.Drawing.Size(197, 55);
            this.butDoanhThu.TabIndex = 10;
            this.butDoanhThu.Text = "Doanh thu ";
            this.butDoanhThu.Click += new System.EventHandler(this.butDoanhThu_Click);
            // 
            // butPhuKien
            // 
            this.butPhuKien.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butPhuKien.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butPhuKien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butPhuKien.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butPhuKien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butPhuKien.FillColor = System.Drawing.Color.DimGray;
            this.butPhuKien.FillColor2 = System.Drawing.Color.Gainsboro;
            this.butPhuKien.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.butPhuKien.ForeColor = System.Drawing.Color.Black;
            this.butPhuKien.Location = new System.Drawing.Point(0, 391);
            this.butPhuKien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butPhuKien.Name = "butPhuKien";
            this.butPhuKien.Size = new System.Drawing.Size(197, 55);
            this.butPhuKien.TabIndex = 9;
            this.butPhuKien.Text = "Phụ kiện";
            this.butPhuKien.Click += new System.EventHandler(this.butPhuKien_Click);
            // 
            // butNhacCu
            // 
            this.butNhacCu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butNhacCu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butNhacCu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butNhacCu.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butNhacCu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butNhacCu.FillColor = System.Drawing.Color.DimGray;
            this.butNhacCu.FillColor2 = System.Drawing.Color.Gainsboro;
            this.butNhacCu.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.butNhacCu.ForeColor = System.Drawing.Color.Black;
            this.butNhacCu.Location = new System.Drawing.Point(0, 310);
            this.butNhacCu.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butNhacCu.Name = "butNhacCu";
            this.butNhacCu.Size = new System.Drawing.Size(197, 55);
            this.butNhacCu.TabIndex = 8;
            this.butNhacCu.Text = "Nhạc cụ";
            this.butNhacCu.Click += new System.EventHandler(this.butNhacCu_Click);
            // 
            // butHoaDon
            // 
            this.butHoaDon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHoaDon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHoaDon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHoaDon.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHoaDon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHoaDon.FillColor = System.Drawing.Color.DimGray;
            this.butHoaDon.FillColor2 = System.Drawing.Color.Gainsboro;
            this.butHoaDon.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.butHoaDon.ForeColor = System.Drawing.Color.Black;
            this.butHoaDon.Location = new System.Drawing.Point(0, 230);
            this.butHoaDon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butHoaDon.Name = "butHoaDon";
            this.butHoaDon.Size = new System.Drawing.Size(197, 55);
            this.butHoaDon.TabIndex = 7;
            this.butHoaDon.Text = "Hóa đơn";
            this.butHoaDon.Click += new System.EventHandler(this.butHoaDon_Click);
            // 
            // butKhachHang
            // 
            this.butKhachHang.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butKhachHang.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butKhachHang.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butKhachHang.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butKhachHang.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butKhachHang.FillColor = System.Drawing.Color.DimGray;
            this.butKhachHang.FillColor2 = System.Drawing.Color.Gainsboro;
            this.butKhachHang.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold);
            this.butKhachHang.ForeColor = System.Drawing.Color.Black;
            this.butKhachHang.Location = new System.Drawing.Point(0, 148);
            this.butKhachHang.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butKhachHang.Name = "butKhachHang";
            this.butKhachHang.Size = new System.Drawing.Size(197, 55);
            this.butKhachHang.TabIndex = 0;
            this.butKhachHang.Text = "Khách hàng";
            this.butKhachHang.Click += new System.EventHandler(this.butKhachHang_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2Panel1.BackgroundImage")));
            this.guna2Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(197, 124);
            this.guna2Panel1.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(197, 95);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(977, 476);
            this.panel3.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel2.Controls.Add(this.butThongTin);
            this.panel2.Controls.Add(this.butThoat);
            this.panel2.Controls.Add(this.labelTenND);
            this.panel2.Controls.Add(this.labelMaND);
            this.panel2.Controls.Add(this.guna2HtmlLabel1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(197, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1088, 95);
            this.panel2.TabIndex = 1;
            // 
            // butThongTin
            // 
            this.butThongTin.Location = new System.Drawing.Point(961, 48);
            this.butThongTin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butThongTin.Name = "butThongTin";
            this.butThongTin.Size = new System.Drawing.Size(80, 26);
            this.butThongTin.TabIndex = 5;
            this.butThongTin.Text = "Thông tin";
            this.butThongTin.UseVisualStyleBackColor = true;
            this.butThongTin.Click += new System.EventHandler(this.butThongTin_Click);
            // 
            // butThoat
            // 
            this.butThoat.Location = new System.Drawing.Point(961, 15);
            this.butThoat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butThoat.Name = "butThoat";
            this.butThoat.Size = new System.Drawing.Size(80, 26);
            this.butThoat.TabIndex = 4;
            this.butThoat.Text = "Thoát";
            this.butThoat.UseVisualStyleBackColor = true;
            this.butThoat.Click += new System.EventHandler(this.butThoat_Click);
            // 
            // labelTenND
            // 
            this.labelTenND.BackColor = System.Drawing.Color.Transparent;
            this.labelTenND.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenND.Location = new System.Drawing.Point(793, 48);
            this.labelTenND.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelTenND.Name = "labelTenND";
            this.labelTenND.Size = new System.Drawing.Size(49, 22);
            this.labelTenND.TabIndex = 3;
            this.labelTenND.Text = "hoten";
            // 
            // labelMaND
            // 
            this.labelMaND.BackColor = System.Drawing.Color.Transparent;
            this.labelMaND.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMaND.Location = new System.Drawing.Point(827, 15);
            this.labelMaND.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelMaND.Name = "labelMaND";
            this.labelMaND.Size = new System.Drawing.Size(22, 22);
            this.labelMaND.TabIndex = 2;
            this.labelMaND.Text = "ID";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(793, 15);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(24, 22);
            this.guna2HtmlLabel1.TabIndex = 1;
            this.guna2HtmlLabel1.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label1.Location = new System.Drawing.Point(291, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(361, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cửa Hàng Nhạc Cụ PTL";
            // 
            // panelBody
            // 
            this.panelBody.BackColor = System.Drawing.Color.SlateGray;
            this.panelBody.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBody.Location = new System.Drawing.Point(197, 95);
            this.panelBody.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(1088, 583);
            this.panelBody.TabIndex = 2;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 678);
            this.Controls.Add(this.panelBody);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panelBody;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private Guna.UI2.WinForms.Guna2GradientButton butDoanhThu;
        private Guna.UI2.WinForms.Guna2GradientButton butPhuKien;
        private Guna.UI2.WinForms.Guna2GradientButton butNhacCu;
        private Guna.UI2.WinForms.Guna2GradientButton butHoaDon;
        private Guna.UI2.WinForms.Guna2GradientButton butKhachHang;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelTenND;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelMaND;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private System.Windows.Forms.Button butThoat;
        private System.Windows.Forms.Button butThongTin;
    }
}

