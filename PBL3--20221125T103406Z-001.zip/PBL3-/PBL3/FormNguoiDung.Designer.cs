﻿namespace PBL3
{
    partial class FormNguoiDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormNguoiDung));
            this.butXoa = new System.Windows.Forms.Button();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.labelMaND = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxNu = new System.Windows.Forms.CheckBox();
            this.checkBoxNam = new System.Windows.Forms.CheckBox();
            this.guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.txtDiaChi = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtCMND = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtTenND = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtTenDangNhap = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtSDT = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.butViewMKM = new Guna.UI2.WinForms.Guna2Button();
            this.butViewNLMK = new Guna.UI2.WinForms.Guna2Button();
            this.butViewMK = new Guna.UI2.WinForms.Guna2Button();
            this.butDoiMK = new Guna.UI2.WinForms.Guna2Button();
            this.txtMatKhauMoi = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtNhapLaiMatKhau = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txtMatKhau = new Guna.UI2.WinForms.Guna2TextBox();
            this.butHideMK = new Guna.UI2.WinForms.Guna2Button();
            this.butHideMKM = new Guna.UI2.WinForms.Guna2Button();
            this.butHideNLMK = new Guna.UI2.WinForms.Guna2Button();
            this.butCapNhat = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // butXoa
            // 
            this.butXoa.Location = new System.Drawing.Point(890, 9);
            this.butXoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butXoa.Name = "butXoa";
            this.butXoa.Size = new System.Drawing.Size(158, 39);
            this.butXoa.TabIndex = 156;
            this.butXoa.Text = "Xóa tài khoản";
            this.butXoa.UseVisualStyleBackColor = true;
            this.butXoa.Click += new System.EventHandler(this.butXoa_Click);
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(13, 26);
            this.guna2HtmlLabel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(24, 22);
            this.guna2HtmlLabel6.TabIndex = 157;
            this.guna2HtmlLabel6.Text = "ID:";
            // 
            // labelMaND
            // 
            this.labelMaND.BackColor = System.Drawing.Color.Transparent;
            this.labelMaND.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMaND.Location = new System.Drawing.Point(45, 26);
            this.labelMaND.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.labelMaND.Name = "labelMaND";
            this.labelMaND.Size = new System.Drawing.Size(22, 22);
            this.labelMaND.TabIndex = 158;
            this.labelMaND.Text = "ID";
            this.labelMaND.Click += new System.EventHandler(this.labelMaND_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.checkBoxNu);
            this.groupBox1.Controls.Add(this.checkBoxNam);
            this.groupBox1.Controls.Add(this.guna2DateTimePicker1);
            this.groupBox1.Controls.Add(this.txtDiaChi);
            this.groupBox1.Controls.Add(this.txtCMND);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel12);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel11);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel10);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel9);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel5);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel1);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtTenND);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel3);
            this.groupBox1.Controls.Add(this.txtTenDangNhap);
            this.groupBox1.Controls.Add(this.txtSDT);
            this.groupBox1.Controls.Add(this.guna2HtmlLabel2);
            this.groupBox1.Location = new System.Drawing.Point(29, 55);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1056, 543);
            this.groupBox1.TabIndex = 161;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin người dùng";
            // 
            // checkBoxNu
            // 
            this.checkBoxNu.AutoSize = true;
            this.checkBoxNu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxNu.Location = new System.Drawing.Point(861, 194);
            this.checkBoxNu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxNu.Name = "checkBoxNu";
            this.checkBoxNu.Size = new System.Drawing.Size(52, 24);
            this.checkBoxNu.TabIndex = 180;
            this.checkBoxNu.Text = "Nữ";
            this.checkBoxNu.UseVisualStyleBackColor = true;
            this.checkBoxNu.CheckedChanged += new System.EventHandler(this.checkBoxNu_CheckedChanged);
            // 
            // checkBoxNam
            // 
            this.checkBoxNam.AutoSize = true;
            this.checkBoxNam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxNam.Location = new System.Drawing.Point(725, 194);
            this.checkBoxNam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxNam.Name = "checkBoxNam";
            this.checkBoxNam.Size = new System.Drawing.Size(66, 24);
            this.checkBoxNam.TabIndex = 179;
            this.checkBoxNam.Text = "Nam";
            this.checkBoxNam.UseVisualStyleBackColor = true;
            this.checkBoxNam.CheckedChanged += new System.EventHandler(this.checkBoxNam_CheckedChanged);
            // 
            // guna2DateTimePicker1
            // 
            this.guna2DateTimePicker1.AutoRoundedCorners = true;
            this.guna2DateTimePicker1.BorderRadius = 17;
            this.guna2DateTimePicker1.Checked = true;
            this.guna2DateTimePicker1.FillColor = System.Drawing.Color.GhostWhite;
            this.guna2DateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1.Location = new System.Drawing.Point(725, 128);
            this.guna2DateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2DateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            this.guna2DateTimePicker1.Size = new System.Drawing.Size(231, 36);
            this.guna2DateTimePicker1.TabIndex = 178;
            this.guna2DateTimePicker1.Value = new System.DateTime(2022, 6, 12, 23, 55, 13, 511);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.AutoRoundedCorners = true;
            this.txtDiaChi.BackColor = System.Drawing.Color.SlateGray;
            this.txtDiaChi.BorderRadius = 17;
            this.txtDiaChi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDiaChi.DefaultText = "";
            this.txtDiaChi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDiaChi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDiaChi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiaChi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDiaChi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiaChi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDiaChi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDiaChi.Location = new System.Drawing.Point(725, 25);
            this.txtDiaChi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.PasswordChar = '\0';
            this.txtDiaChi.PlaceholderText = "";
            this.txtDiaChi.SelectedText = "";
            this.txtDiaChi.Size = new System.Drawing.Size(231, 36);
            this.txtDiaChi.TabIndex = 177;
            // 
            // txtCMND
            // 
            this.txtCMND.AutoRoundedCorners = true;
            this.txtCMND.BackColor = System.Drawing.Color.SlateGray;
            this.txtCMND.BorderRadius = 17;
            this.txtCMND.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCMND.DefaultText = "";
            this.txtCMND.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtCMND.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtCMND.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCMND.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtCMND.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCMND.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCMND.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtCMND.Location = new System.Drawing.Point(725, 79);
            this.txtCMND.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.PasswordChar = '\0';
            this.txtCMND.PlaceholderText = "";
            this.txtCMND.SelectedText = "";
            this.txtCMND.Size = new System.Drawing.Size(231, 36);
            this.txtCMND.TabIndex = 176;
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(569, 192);
            this.guna2HtmlLabel12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(70, 22);
            this.guna2HtmlLabel12.TabIndex = 173;
            this.guna2HtmlLabel12.Text = "Giới tính";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(569, 25);
            this.guna2HtmlLabel11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(58, 22);
            this.guna2HtmlLabel11.TabIndex = 172;
            this.guna2HtmlLabel11.Text = "Địa chỉ";
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(569, 79);
            this.guna2HtmlLabel10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(54, 22);
            this.guna2HtmlLabel10.TabIndex = 171;
            this.guna2HtmlLabel10.Text = "CMND";
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(569, 142);
            this.guna2HtmlLabel9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(81, 22);
            this.guna2HtmlLabel9.TabIndex = 170;
            this.guna2HtmlLabel9.Text = "Ngày sinh";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(109, 156);
            this.guna2HtmlLabel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(47, 22);
            this.guna2HtmlLabel5.TabIndex = 169;
            this.guna2HtmlLabel5.Text = "Email";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(101, 38);
            this.guna2HtmlLabel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(127, 22);
            this.guna2HtmlLabel1.TabIndex = 162;
            this.guna2HtmlLabel1.Text = "Tên người dùng";
            // 
            // txtEmail
            // 
            this.txtEmail.AutoRoundedCorners = true;
            this.txtEmail.BackColor = System.Drawing.Color.SlateGray;
            this.txtEmail.BorderRadius = 17;
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.DefaultText = "";
            this.txtEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtEmail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmail.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtEmail.Location = new System.Drawing.Point(256, 142);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PasswordChar = '\0';
            this.txtEmail.PlaceholderText = "";
            this.txtEmail.SelectedText = "";
            this.txtEmail.Size = new System.Drawing.Size(231, 36);
            this.txtEmail.TabIndex = 168;
            // 
            // txtTenND
            // 
            this.txtTenND.AutoRoundedCorners = true;
            this.txtTenND.BackColor = System.Drawing.Color.SlateGray;
            this.txtTenND.BorderRadius = 17;
            this.txtTenND.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenND.DefaultText = "";
            this.txtTenND.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTenND.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTenND.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenND.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenND.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenND.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTenND.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenND.Location = new System.Drawing.Point(256, 25);
            this.txtTenND.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTenND.Name = "txtTenND";
            this.txtTenND.PasswordChar = '\0';
            this.txtTenND.PlaceholderText = "";
            this.txtTenND.SelectedText = "";
            this.txtTenND.Size = new System.Drawing.Size(231, 36);
            this.txtTenND.TabIndex = 165;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(101, 94);
            this.guna2HtmlLabel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(123, 22);
            this.guna2HtmlLabel3.TabIndex = 164;
            this.guna2HtmlLabel3.Text = "Tên đăng nhập";
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.AutoRoundedCorners = true;
            this.txtTenDangNhap.BackColor = System.Drawing.Color.SlateGray;
            this.txtTenDangNhap.BorderRadius = 17;
            this.txtTenDangNhap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenDangNhap.DefaultText = "";
            this.txtTenDangNhap.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTenDangNhap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTenDangNhap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenDangNhap.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenDangNhap.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenDangNhap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTenDangNhap.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenDangNhap.Location = new System.Drawing.Point(256, 79);
            this.txtTenDangNhap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.PasswordChar = '\0';
            this.txtTenDangNhap.PlaceholderText = "";
            this.txtTenDangNhap.SelectedText = "";
            this.txtTenDangNhap.Size = new System.Drawing.Size(231, 36);
            this.txtTenDangNhap.TabIndex = 166;
            // 
            // txtSDT
            // 
            this.txtSDT.AutoRoundedCorners = true;
            this.txtSDT.BackColor = System.Drawing.Color.SlateGray;
            this.txtSDT.BorderRadius = 17;
            this.txtSDT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSDT.DefaultText = "";
            this.txtSDT.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtSDT.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtSDT.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSDT.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtSDT.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSDT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtSDT.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtSDT.Location = new System.Drawing.Point(256, 192);
            this.txtSDT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.PasswordChar = '\0';
            this.txtSDT.PlaceholderText = "";
            this.txtSDT.SelectedText = "";
            this.txtSDT.Size = new System.Drawing.Size(231, 36);
            this.txtSDT.TabIndex = 167;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(101, 206);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(109, 22);
            this.guna2HtmlLabel2.TabIndex = 163;
            this.guna2HtmlLabel2.Text = "Số điện thoại";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.butViewMKM);
            this.groupBox2.Controls.Add(this.butViewNLMK);
            this.groupBox2.Controls.Add(this.butViewMK);
            this.groupBox2.Controls.Add(this.butDoiMK);
            this.groupBox2.Controls.Add(this.txtMatKhauMoi);
            this.groupBox2.Controls.Add(this.guna2HtmlLabel8);
            this.groupBox2.Controls.Add(this.guna2HtmlLabel4);
            this.groupBox2.Controls.Add(this.txtNhapLaiMatKhau);
            this.groupBox2.Controls.Add(this.guna2HtmlLabel7);
            this.groupBox2.Controls.Add(this.txtMatKhau);
            this.groupBox2.Controls.Add(this.butHideMK);
            this.groupBox2.Controls.Add(this.butHideMKM);
            this.groupBox2.Controls.Add(this.butHideNLMK);
            this.groupBox2.Location = new System.Drawing.Point(244, 264);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(531, 218);
            this.groupBox2.TabIndex = 162;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Đổi mật khẩu";
            // 
            // butViewMKM
            // 
            this.butViewMKM.Animated = true;
            this.butViewMKM.BackColor = System.Drawing.Color.Transparent;
            this.butViewMKM.BorderColor = System.Drawing.Color.Transparent;
            this.butViewMKM.BorderRadius = 8;
            this.butViewMKM.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butViewMKM.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butViewMKM.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butViewMKM.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butViewMKM.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butViewMKM.FillColor = System.Drawing.Color.White;
            this.butViewMKM.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butViewMKM.ForeColor = System.Drawing.Color.White;
            this.butViewMKM.Image = ((System.Drawing.Image)(resources.GetObject("butViewMKM.Image")));
            this.butViewMKM.ImageSize = new System.Drawing.Size(25, 25);
            this.butViewMKM.Location = new System.Drawing.Point(445, 68);
            this.butViewMKM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butViewMKM.Name = "butViewMKM";
            this.butViewMKM.Size = new System.Drawing.Size(41, 37);
            this.butViewMKM.TabIndex = 166;
            this.butViewMKM.UseTransparentBackground = true;
            this.butViewMKM.Click += new System.EventHandler(this.butViewMKM_Click);
            // 
            // butViewNLMK
            // 
            this.butViewNLMK.Animated = true;
            this.butViewNLMK.BackColor = System.Drawing.Color.Transparent;
            this.butViewNLMK.BorderColor = System.Drawing.Color.Transparent;
            this.butViewNLMK.BorderRadius = 8;
            this.butViewNLMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butViewNLMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butViewNLMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butViewNLMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butViewNLMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butViewNLMK.FillColor = System.Drawing.Color.White;
            this.butViewNLMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butViewNLMK.ForeColor = System.Drawing.Color.White;
            this.butViewNLMK.Image = ((System.Drawing.Image)(resources.GetObject("butViewNLMK.Image")));
            this.butViewNLMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butViewNLMK.Location = new System.Drawing.Point(445, 114);
            this.butViewNLMK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butViewNLMK.Name = "butViewNLMK";
            this.butViewNLMK.Size = new System.Drawing.Size(41, 37);
            this.butViewNLMK.TabIndex = 165;
            this.butViewNLMK.UseTransparentBackground = true;
            this.butViewNLMK.Click += new System.EventHandler(this.butViewNLMK_Click);
            // 
            // butViewMK
            // 
            this.butViewMK.Animated = true;
            this.butViewMK.BackColor = System.Drawing.Color.Transparent;
            this.butViewMK.BorderColor = System.Drawing.Color.Transparent;
            this.butViewMK.BorderRadius = 8;
            this.butViewMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butViewMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butViewMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butViewMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butViewMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butViewMK.FillColor = System.Drawing.Color.White;
            this.butViewMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butViewMK.ForeColor = System.Drawing.Color.White;
            this.butViewMK.Image = ((System.Drawing.Image)(resources.GetObject("butViewMK.Image")));
            this.butViewMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butViewMK.Location = new System.Drawing.Point(445, 21);
            this.butViewMK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butViewMK.Name = "butViewMK";
            this.butViewMK.Size = new System.Drawing.Size(41, 37);
            this.butViewMK.TabIndex = 164;
            this.butViewMK.UseTransparentBackground = true;
            this.butViewMK.Click += new System.EventHandler(this.butViewMK_Click);
            // 
            // butDoiMK
            // 
            this.butDoiMK.BorderRadius = 20;
            this.butDoiMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butDoiMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butDoiMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butDoiMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butDoiMK.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.butDoiMK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butDoiMK.ForeColor = System.Drawing.Color.White;
            this.butDoiMK.Location = new System.Drawing.Point(186, 157);
            this.butDoiMK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butDoiMK.Name = "butDoiMK";
            this.butDoiMK.Size = new System.Drawing.Size(181, 49);
            this.butDoiMK.TabIndex = 160;
            this.butDoiMK.Text = "Đổi mật khẩu";
            this.butDoiMK.Click += new System.EventHandler(this.butDoiMK_Click);
            // 
            // txtMatKhauMoi
            // 
            this.txtMatKhauMoi.AutoRoundedCorners = true;
            this.txtMatKhauMoi.BackColor = System.Drawing.Color.SlateGray;
            this.txtMatKhauMoi.BorderRadius = 17;
            this.txtMatKhauMoi.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMatKhauMoi.DefaultText = "";
            this.txtMatKhauMoi.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMatKhauMoi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMatKhauMoi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhauMoi.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhauMoi.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhauMoi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMatKhauMoi.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhauMoi.Location = new System.Drawing.Point(247, 68);
            this.txtMatKhauMoi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatKhauMoi.Name = "txtMatKhauMoi";
            this.txtMatKhauMoi.PasswordChar = '●';
            this.txtMatKhauMoi.PlaceholderText = "";
            this.txtMatKhauMoi.SelectedText = "";
            this.txtMatKhauMoi.Size = new System.Drawing.Size(240, 36);
            this.txtMatKhauMoi.TabIndex = 163;
            this.txtMatKhauMoi.UseSystemPasswordChar = true;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.OldLace;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(16, 82);
            this.guna2HtmlLabel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(110, 22);
            this.guna2HtmlLabel8.TabIndex = 162;
            this.guna2HtmlLabel8.Text = "Mật khẩu mới";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.PapayaWhip;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(16, 129);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(180, 22);
            this.guna2HtmlLabel4.TabIndex = 159;
            this.guna2HtmlLabel4.Text = "Nhập lại mật khẩu mới";
            // 
            // txtNhapLaiMatKhau
            // 
            this.txtNhapLaiMatKhau.AutoRoundedCorners = true;
            this.txtNhapLaiMatKhau.BackColor = System.Drawing.Color.SlateGray;
            this.txtNhapLaiMatKhau.BorderRadius = 17;
            this.txtNhapLaiMatKhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNhapLaiMatKhau.DefaultText = "";
            this.txtNhapLaiMatKhau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtNhapLaiMatKhau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtNhapLaiMatKhau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtNhapLaiMatKhau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtNhapLaiMatKhau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNhapLaiMatKhau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNhapLaiMatKhau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtNhapLaiMatKhau.Location = new System.Drawing.Point(247, 114);
            this.txtNhapLaiMatKhau.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNhapLaiMatKhau.Name = "txtNhapLaiMatKhau";
            this.txtNhapLaiMatKhau.PasswordChar = '●';
            this.txtNhapLaiMatKhau.PlaceholderText = "";
            this.txtNhapLaiMatKhau.SelectedText = "";
            this.txtNhapLaiMatKhau.Size = new System.Drawing.Size(240, 36);
            this.txtNhapLaiMatKhau.TabIndex = 157;
            this.txtNhapLaiMatKhau.UseSystemPasswordChar = true;
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.SlateGray;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.OldLace;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(16, 36);
            this.guna2HtmlLabel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(77, 22);
            this.guna2HtmlLabel7.TabIndex = 161;
            this.guna2HtmlLabel7.Text = "Mật khẩu";
            // 
            // txtMatKhau
            // 
            this.txtMatKhau.AutoRoundedCorners = true;
            this.txtMatKhau.BackColor = System.Drawing.Color.SlateGray;
            this.txtMatKhau.BorderRadius = 17;
            this.txtMatKhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMatKhau.DefaultText = "";
            this.txtMatKhau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMatKhau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMatKhau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatKhau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMatKhau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatKhau.Location = new System.Drawing.Point(247, 22);
            this.txtMatKhau.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMatKhau.Name = "txtMatKhau";
            this.txtMatKhau.PasswordChar = '●';
            this.txtMatKhau.PlaceholderText = "";
            this.txtMatKhau.SelectedText = "";
            this.txtMatKhau.Size = new System.Drawing.Size(240, 36);
            this.txtMatKhau.TabIndex = 158;
            this.txtMatKhau.UseSystemPasswordChar = true;
            // 
            // butHideMK
            // 
            this.butHideMK.Animated = true;
            this.butHideMK.BackColor = System.Drawing.Color.Transparent;
            this.butHideMK.BorderRadius = 8;
            this.butHideMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butHideMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHideMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHideMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHideMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHideMK.FillColor = System.Drawing.Color.White;
            this.butHideMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butHideMK.ForeColor = System.Drawing.Color.White;
            this.butHideMK.Image = ((System.Drawing.Image)(resources.GetObject("butHideMK.Image")));
            this.butHideMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butHideMK.Location = new System.Drawing.Point(445, 21);
            this.butHideMK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butHideMK.Name = "butHideMK";
            this.butHideMK.Size = new System.Drawing.Size(41, 37);
            this.butHideMK.TabIndex = 165;
            this.butHideMK.UseTransparentBackground = true;
            this.butHideMK.Click += new System.EventHandler(this.butHideMK_Click);
            // 
            // butHideMKM
            // 
            this.butHideMKM.Animated = true;
            this.butHideMKM.BackColor = System.Drawing.Color.Transparent;
            this.butHideMKM.BorderRadius = 8;
            this.butHideMKM.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butHideMKM.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHideMKM.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHideMKM.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHideMKM.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHideMKM.FillColor = System.Drawing.Color.White;
            this.butHideMKM.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butHideMKM.ForeColor = System.Drawing.Color.White;
            this.butHideMKM.Image = ((System.Drawing.Image)(resources.GetObject("butHideMKM.Image")));
            this.butHideMKM.ImageSize = new System.Drawing.Size(25, 25);
            this.butHideMKM.Location = new System.Drawing.Point(445, 66);
            this.butHideMKM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butHideMKM.Name = "butHideMKM";
            this.butHideMKM.Size = new System.Drawing.Size(41, 37);
            this.butHideMKM.TabIndex = 164;
            this.butHideMKM.UseTransparentBackground = true;
            this.butHideMKM.Click += new System.EventHandler(this.butHideMKM_Click);
            // 
            // butHideNLMK
            // 
            this.butHideNLMK.Animated = true;
            this.butHideNLMK.BackColor = System.Drawing.Color.Transparent;
            this.butHideNLMK.BorderRadius = 8;
            this.butHideNLMK.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.butHideNLMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butHideNLMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butHideNLMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butHideNLMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butHideNLMK.FillColor = System.Drawing.Color.White;
            this.butHideNLMK.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.butHideNLMK.ForeColor = System.Drawing.Color.White;
            this.butHideNLMK.Image = ((System.Drawing.Image)(resources.GetObject("butHideNLMK.Image")));
            this.butHideNLMK.ImageSize = new System.Drawing.Size(25, 25);
            this.butHideNLMK.Location = new System.Drawing.Point(445, 114);
            this.butHideNLMK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.butHideNLMK.Name = "butHideNLMK";
            this.butHideNLMK.Size = new System.Drawing.Size(41, 37);
            this.butHideNLMK.TabIndex = 163;
            this.butHideNLMK.UseTransparentBackground = true;
            this.butHideNLMK.Click += new System.EventHandler(this.butHideNLMK_Click);
            // 
            // butCapNhat
            // 
            this.butCapNhat.Location = new System.Drawing.Point(678, 9);
            this.butCapNhat.Margin = new System.Windows.Forms.Padding(4);
            this.butCapNhat.Name = "butCapNhat";
            this.butCapNhat.Size = new System.Drawing.Size(175, 39);
            this.butCapNhat.TabIndex = 181;
            this.butCapNhat.Text = "Cập nhật thông tin";
            this.butCapNhat.UseVisualStyleBackColor = true;
            this.butCapNhat.Click += new System.EventHandler(this.butCapNhat_Click);
            // 
            // FormNguoiDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1107, 603);
            this.Controls.Add(this.butCapNhat);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.labelMaND);
            this.Controls.Add(this.butXoa);
            this.Controls.Add(this.guna2HtmlLabel6);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormNguoiDung";
            this.Text = "FormNguoiDung";
            this.Load += new System.EventHandler(this.FormNguoiDung_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button butXoa;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel labelMaND;
        private System.Windows.Forms.GroupBox groupBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtDiaChi;
        private Guna.UI2.WinForms.Guna2TextBox txtCMND;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtTenND;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2TextBox txtTenDangNhap;
        private Guna.UI2.WinForms.Guna2TextBox txtSDT;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI2.WinForms.Guna2Button butDoiMK;
        private Guna.UI2.WinForms.Guna2TextBox txtMatKhauMoi;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox txtNhapLaiMatKhau;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2TextBox txtMatKhau;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private System.Windows.Forms.CheckBox checkBoxNu;
        private System.Windows.Forms.CheckBox checkBoxNam;
        private Guna.UI2.WinForms.Guna2Button butViewMKM;
        private Guna.UI2.WinForms.Guna2Button butViewNLMK;
        private Guna.UI2.WinForms.Guna2Button butViewMK;
        private Guna.UI2.WinForms.Guna2Button butHideNLMK;
        private Guna.UI2.WinForms.Guna2Button butHideMKM;
        private Guna.UI2.WinForms.Guna2Button butHideMK;
        private System.Windows.Forms.Button butCapNhat;
    }
}