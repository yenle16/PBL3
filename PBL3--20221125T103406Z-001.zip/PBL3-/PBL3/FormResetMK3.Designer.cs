﻿namespace PBL3
{
    partial class FormResetMK3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormResetMK3));
            this.txtnewpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.buttoneyes1 = new Guna.UI2.WinForms.Guna2Button();
            this.buttoneyes2 = new Guna.UI2.WinForms.Guna2Button();
            this.txtconfirmpass = new Guna.UI2.WinForms.Guna2TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.butThaydoiMK = new Guna.UI2.WinForms.Guna2Button();
            this.gunaback = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // txtnewpass
            // 
            this.txtnewpass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtnewpass.BorderRadius = 20;
            this.txtnewpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtnewpass.DefaultText = "";
            this.txtnewpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtnewpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtnewpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnewpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtnewpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtnewpass.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtnewpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtnewpass.IconLeftSize = new System.Drawing.Size(25, 25);
            this.txtnewpass.Location = new System.Drawing.Point(641, 208);
            this.txtnewpass.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtnewpass.Name = "txtnewpass";
            this.txtnewpass.PasswordChar = '●';
            this.txtnewpass.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtnewpass.PlaceholderText = "Mật khẩu mới";
            this.txtnewpass.SelectedText = "";
            this.txtnewpass.Size = new System.Drawing.Size(371, 60);
            this.txtnewpass.TabIndex = 104;
            this.txtnewpass.UseSystemPasswordChar = true;
            // 
            // buttoneyes1
            // 
            this.buttoneyes1.Animated = true;
            this.buttoneyes1.BackColor = System.Drawing.Color.Transparent;
            this.buttoneyes1.BorderRadius = 8;
            this.buttoneyes1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.buttoneyes1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttoneyes1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttoneyes1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttoneyes1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttoneyes1.FillColor = System.Drawing.Color.White;
            this.buttoneyes1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttoneyes1.ForeColor = System.Drawing.Color.White;
            this.buttoneyes1.Image = ((System.Drawing.Image)(resources.GetObject("buttoneyes1.Image")));
            this.buttoneyes1.ImageSize = new System.Drawing.Size(25, 25);
            this.buttoneyes1.Location = new System.Drawing.Point(951, 217);
            this.buttoneyes1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttoneyes1.Name = "buttoneyes1";
            this.buttoneyes1.Size = new System.Drawing.Size(41, 37);
            this.buttoneyes1.TabIndex = 126;
            this.buttoneyes1.UseTransparentBackground = true;
            this.buttoneyes1.Click += new System.EventHandler(this.buttoneyes1_Click);
            // 
            // buttoneyes2
            // 
            this.buttoneyes2.Animated = true;
            this.buttoneyes2.BackColor = System.Drawing.Color.Transparent;
            this.buttoneyes2.BorderRadius = 8;
            this.buttoneyes2.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.buttoneyes2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.buttoneyes2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.buttoneyes2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.buttoneyes2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.buttoneyes2.FillColor = System.Drawing.Color.White;
            this.buttoneyes2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.buttoneyes2.ForeColor = System.Drawing.Color.White;
            this.buttoneyes2.Image = ((System.Drawing.Image)(resources.GetObject("buttoneyes2.Image")));
            this.buttoneyes2.ImageSize = new System.Drawing.Size(25, 25);
            this.buttoneyes2.Location = new System.Drawing.Point(951, 217);
            this.buttoneyes2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttoneyes2.Name = "buttoneyes2";
            this.buttoneyes2.Size = new System.Drawing.Size(41, 37);
            this.buttoneyes2.TabIndex = 127;
            this.buttoneyes2.UseTransparentBackground = true;
            this.buttoneyes2.Click += new System.EventHandler(this.buttoneyes2_Click);
            // 
            // txtconfirmpass
            // 
            this.txtconfirmpass.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.txtconfirmpass.BorderRadius = 20;
            this.txtconfirmpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtconfirmpass.DefaultText = "";
            this.txtconfirmpass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtconfirmpass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtconfirmpass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtconfirmpass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtconfirmpass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtconfirmpass.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtconfirmpass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtconfirmpass.IconLeftSize = new System.Drawing.Size(25, 25);
            this.txtconfirmpass.Location = new System.Drawing.Point(641, 301);
            this.txtconfirmpass.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtconfirmpass.Name = "txtconfirmpass";
            this.txtconfirmpass.PasswordChar = '●';
            this.txtconfirmpass.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(134)))), ((int)(((byte)(146)))), ((int)(((byte)(166)))));
            this.txtconfirmpass.PlaceholderText = "Xác nhận mật khẩu";
            this.txtconfirmpass.SelectedText = "";
            this.txtconfirmpass.Size = new System.Drawing.Size(371, 60);
            this.txtconfirmpass.TabIndex = 128;
            this.txtconfirmpass.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(635, 101);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(338, 33);
            this.label1.TabIndex = 129;
            this.label1.Text = "Đặt lại mật khẩu của bạn";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(196)))), ((int)(((byte)(196)))));
            this.label4.Location = new System.Drawing.Point(636, 148);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(309, 25);
            this.label4.TabIndex = 130;
            this.label4.Text = "___________________________";
            // 
            // butThaydoiMK
            // 
            this.butThaydoiMK.BorderRadius = 20;
            this.butThaydoiMK.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.butThaydoiMK.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.butThaydoiMK.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.butThaydoiMK.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.butThaydoiMK.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(66)))), ((int)(((byte)(110)))));
            this.butThaydoiMK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butThaydoiMK.ForeColor = System.Drawing.Color.White;
            this.butThaydoiMK.Location = new System.Drawing.Point(641, 410);
            this.butThaydoiMK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.butThaydoiMK.Name = "butThaydoiMK";
            this.butThaydoiMK.Size = new System.Drawing.Size(371, 60);
            this.butThaydoiMK.TabIndex = 131;
            this.butThaydoiMK.Text = "Thay đổi mật khẩu";
            this.butThaydoiMK.Click += new System.EventHandler(this.butThaydoiMK_Click);
            // 
            // gunaback
            // 
            this.gunaback.BackColor = System.Drawing.Color.SlateGray;
            this.gunaback.BorderRadius = 21;
            this.gunaback.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gunaback.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gunaback.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gunaback.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gunaback.FillColor = System.Drawing.Color.SlateGray;
            this.gunaback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.gunaback.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(45)))), ((int)(((byte)(29)))));
            this.gunaback.Image = ((System.Drawing.Image)(resources.GetObject("gunaback.Image")));
            this.gunaback.ImageSize = new System.Drawing.Size(40, 40);
            this.gunaback.Location = new System.Drawing.Point(622, 11);
            this.gunaback.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gunaback.Name = "gunaback";
            this.gunaback.Size = new System.Drawing.Size(78, 70);
            this.gunaback.TabIndex = 132;
            this.gunaback.Click += new System.EventHandler(this.gunaback_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 8;
            this.guna2Button1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.White;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button1.Image")));
            this.guna2Button1.ImageSize = new System.Drawing.Size(25, 25);
            this.guna2Button1.Location = new System.Drawing.Point(951, 312);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(41, 37);
            this.guna2Button1.TabIndex = 133;
            this.guna2Button1.UseTransparentBackground = true;
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.Animated = true;
            this.guna2Button2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button2.BorderRadius = 8;
            this.guna2Button2.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.White;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Image = ((System.Drawing.Image)(resources.GetObject("guna2Button2.Image")));
            this.guna2Button2.ImageSize = new System.Drawing.Size(25, 25);
            this.guna2Button2.Location = new System.Drawing.Point(951, 312);
            this.guna2Button2.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(41, 37);
            this.guna2Button2.TabIndex = 134;
            this.guna2Button2.UseTransparentBackground = true;
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // FormResetMK3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1047, 509);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.gunaback);
            this.Controls.Add(this.butThaydoiMK);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtconfirmpass);
            this.Controls.Add(this.buttoneyes2);
            this.Controls.Add(this.buttoneyes1);
            this.Controls.Add(this.txtnewpass);
            this.Controls.Add(this.guna2Button2);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormResetMK3";
            this.Text = "FormResetMK3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtnewpass;
        private Guna.UI2.WinForms.Guna2Button buttoneyes1;
        private Guna.UI2.WinForms.Guna2Button buttoneyes2;
        private Guna.UI2.WinForms.Guna2TextBox txtconfirmpass;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button butThaydoiMK;
        private Guna.UI2.WinForms.Guna2Button gunaback;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
    }
}